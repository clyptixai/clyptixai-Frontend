# ClyptixAI Frontend

A simple starter frontend for the ClyptixAI video generation platform.